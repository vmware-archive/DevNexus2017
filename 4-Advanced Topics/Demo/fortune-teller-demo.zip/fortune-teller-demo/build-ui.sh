cd fortune-teller-ui
mvn package -DskipTests=true
cd ..
